
# Judul dan Identitas diri
print("Program Faktor Bilangan")
print("Nama : Azeilya Junita")
print("NIM  : 1306625032")
print()

# Cara / logika
next = True
def faktorbilangan(n):
    faktor = []
    for i in range(1, n + 1):
        if n % i == 0:
            faktor.append(i)
    return faktor

while next:
    bilangan = int(input("Masukkan sembarang bilangan < 100 ( masukkan 0 untuk selesai ): "))
    if bilangan == 0:
        next = False
    else:
        hasil = faktorbilangan(bilangan)
        print("Bilangan", bilangan, "→ Faktornya = ", hasil)
        print()

print()
print("SELESAI")

