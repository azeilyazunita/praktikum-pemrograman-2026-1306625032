# Judul dan Identitas diri
print("Program Sorting")
print("Nama : Azeilya Junita")
print("NIM  : 1306625032")
print()

Nilai = [
    85, 13, 99, 34, 71, 15, 82, 24, 64, 61,
    67, 99, 50, 68, 25, 37, 32, 27, 14, 91,
    79, 15, 47, 48, 74, 88, 64, 53, 77, 50,
    24, 91, 87, 55, 60, 75, 91, 22, 47, 63,
    81, 88, 26, 48, 69, 59, 84, 77, 28, 36,
    59, 74, 89, 73, 91, 64, 55, 88, 90, 48,
    73, 97, 98, 40, 93, 50, 78, 60, 44, 77,
    82, 51, 53, 65, 98, 59, 94, 91, 52, 44,
    65, 85, 72, 92, 49, 67, 58, 48, 62, 54,
    89, 67, 58, 48, 85, 45, 77, 76, 81, 77
]

print("Data nilai awal :")
i = 0
while i < len(Nilai):
    print(Nilai[i], end="")
    if (i + 1) % 10 == 0 or i == len(Nilai) - 1:
        print()
    else:
        print(", ", end="")
    i += 1

# Salin data agar data awal tetap utuh, lalu diurutkan
terurut = Nilai.copy()
n = len(terurut)

i = 0
while i < n - 1:
    j = 0
    while j < n - 1 - i:
        if terurut[j] > terurut[j + 1]:
            temp = terurut[j]
            terurut[j] = terurut[j + 1]
            terurut[j + 1] = temp
        j += 1
    i += 1

# Cetak data terurut, 10 data per baris
print()
print("Data nilai terurut : ")

i = 0
while i < n:
    print(terurut[i], end="")
    if (i + 1) % 10 == 0 or i == n - 1:
        print()
    else:
        print(", ", end="")
    i += 1

print()
print("selesai")