import random

print("Permainan Tebak Nama Buah")
print("Oleh : Azeilya Junita")
print("NIM  : 1306625032")
print()

databuah = [
    'anggur', 'apel', 'aprikot', 'asam', 'atap', 'arbei',
    'abiu', 'alpukat', 'anjeng', 'bacang', 'baguk',
    'belimbing', 'bengkuang', 'benda', 'binjai', 'bisbul',
    'blueberry', 'burahol', 'blewah', 'bit', 'cempedak',
    'ceplukan', 'cermai', 'ceri', 'cokelat', 'delima',
    'duku', 'durian', 'duwet', 'enau', 'enamenam',
    'frambos', 'hamoi', 'hamlam', 'holdi', 'jamblang',
    'jambuair', 'jambubatu', 'jambubol', 'jambumawar',
    'jambumede', 'jengkol', 'jeruk', 'jerukbali',
    'jerukkeprok', 'jerukkingkit', 'jeruknipis',
    'jerukpurut', 'kapulasan', 'kawista', 'kecapi',
    'kedondong', 'kelapa', 'kelengkeng', 'kelubi',
    'ketela', 'kemang', 'kepel', 'kersen', 'kesemek',
    'kokosan', 'kiwi', 'koldi', 'kurma', 'kelawi',
    'kenitu', 'lai', 'langsat', 'lemon', 'leci', 'lobak',
    'maja', 'malaka', 'mangga', 'manggis', 'markisa',
    'melon', 'mengkudu', 'menteng', 'matoa', 'mentimun',
    'namnam', 'nanas', 'nangka', 'naga', 'nona',
    'pepaya', 'persik', 'pir', 'pisang', 'pete', 'rambai',
    'rambusa', 'rambutan', 'rukem', 'sawo', 'semangka',
    'sirsak', 'siwalan', 'srikaya', 'stroberi', 'sukun',
    'terap', 'terong', 'tomat', 'timunsuri', 'ubi',
    'waluh', 'wuni', 'zaitun'
]


def mainkan_buah(databuah):
    buah = random.choice(databuah)
    tampilan = ['-'] * len(buah)
    nyawa = len(buah)
    tebakan = []

    print()
    print("Komputer sedang memikirkan nama buah")
    print(f"yang terdiri dari {len(buah)} huruf.")

    while True:
        print()
        print("Nama buah :", " ".join(tampilan))
        print(f"Anda memiliki {nyawa} kesempatan")
        print("untuk menebak huruf buah tersebut.")

        huruf = input("Tebakan anda? ").lower().strip()

        if len(huruf) != 1 or not huruf.isalpha():
            print("Masukkan satu huruf saja!")
            continue

        if huruf in tebakan:
            print("Huruf tersebut sudah pernah ditebak.")
            continue

        tebakan.append(huruf)

        if huruf in buah:
            print(f"Benar. Huruf {huruf} ada dalam nama buah!")

            for i in range(len(buah)):
                if buah[i] == huruf:
                    tampilan[i] = huruf
        else:
            print(f"Sayang sekali. Huruf {huruf} tidak ada.")
            nyawa -= 1

        if "-" not in tampilan:
            print()
            print("Nama buah :", " ".join(tampilan))
            print("SELAMAT. Anda berhasil!!")
            break

        if nyawa == 0:
            print()
            print("Anda kalah!!")
            print("Nama buah tersebut:", " ".join(buah))
            break


while True:
    mainkan_buah(databuah)

    while True:
        main_lagi = input("Mau main lagi (y/t)? ").lower().strip()

        if main_lagi == "y":
            break
        elif main_lagi == "t":
            print()
            print("# SELESAI #")
            break
        else:
            print("Masukkan y untuk ya atau t untuk tidak.")

    if main_lagi == "t":
        break