
print("Program Sinus-Cosinus")
print("Nama : Azeilya Junita")
print("NIM  : 1306625032")
import math as mt

def factorial(n):
    if n==0:
        return 1
    else:
        return n*factorial(n-1)

def f_sin(x,y):
    total = 0
    for i in range (y):
        pos_neg=(-1)**i
        x_sin=x**(2*i+1)
        fac_sin=1/factorial(2*i+1)
        ordo=pos_neg*x_sin*fac_sin
        total+=ordo
    return round(total,2)

def f_cos(x,y):
    total=0
    for i in range (y):
        pos_neg=(-1)**i
        x_cos=x**(2*i)
        fac_cos=1/factorial(2*i)
        ordo=pos_neg*x_cos*fac_cos
        total+=ordo
    return round(total,2)

print()
ulang ="benar"
while ulang =="benar":
    deg=float(input("Besar sudut (derajat) = "))
    x=mt.radians(deg)
    TVS=round(mt.sin(x),2)
    TVC=round(mt.cos(x),2)
    print()
    print("True Value Sin ({})= {}". format(deg,TVS))
    print("True Value Cos ({})= {}". format(deg,TVC))
    print("-"*69)
    print("|{:^11}|{:^13}|{:^13}|{:^13}|{:^13}|".format("Jumlah Suku","AV Sine","ER Sine","AV Cosine","ER Cosine"))
    print("|{:^11}|{:^13}|{:^13}|{:^13}|{:^13}|".format("-"*11,"-"*13,"-"*13,"-"*13,"-"*13))
    n=1
    while n>0:
        AVS=f_sin(x,n)
        AVC=f_cos(x,n)
        if deg==0 or deg==180 or deg==360:
            AVS=0
            ERS=0
            ERC=abs((AVC-TVC)/TVC)
        elif deg==90 or deg==270:
            AVC=0
            ERS=abs((AVS-TVS)/TVS)
            ERC=0
        else:
            ERS=abs((AVS-TVS)/TVS)
            ERC=abs((AVC-TVC)/TVC)
        print("|{:^11}|{:^13}|{:^13.2%}|{:^13}|{:^13.2%}|".format(n,round(AVS,2),round(ERS,2),round(AVC,2),round(ERC,2)))
        n+=1
        if ERS<=0.05 and ERC<=0.05:
            break

    print("-"*69)
    print()
    k=input("Mau Menghitung Lagi (y/t)? ")
    print()
    if k == "t":
        break
    elif k!= "y":
        print("Pilihannya cuma y atau t, kenapa jawab",k,"?")
        print("Jadi disudahi saja")
    
print("Selesai")