# Judul dan Identitas diri
from pathlib import Path
import openpyxl as xl

print("Program Grading")
print("Nama : Azeilya Junita")
print("NIM  : 1306625032")
print()

def to_float(value):
    if value is None or value == "":
        return 0.0
    if isinstance(value, str):
        value = value.strip().replace(",", ".")
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0
    
def hitung_grade(na):
    if na >= 86:
        return "A"
    elif na >= 81:
        return "A-"
    elif na >= 76:
        return "B+"
    elif na >= 71:
        return "B"
    elif na >= 66:
        return "B-"
    elif na >= 61:
        return "C+"
    elif na >= 56:
        return "C"
    else:
        return "TL"


# 2. Baca data dari file Excel ke dalam list 
script_dir = Path(__file__).resolve().parent
excel_candidates = []
excel_candidates.append(script_dir / "DataNilai.xlsx")
excel_candidates.append(Path(r"C:\Users\Hype AMD\OneDrive\Dokumen\New folder\DataNilai.xlsx"))

excel_path = next((p for p in excel_candidates if p.exists()), excel_candidates[0])

if not excel_path.exists():
    raise FileNotFoundError(f"File Excel tidak ditemukan: {excel_path}")
wb = xl.load_workbook(excel_path, data_only=True)
ws = wb.active

nama = []
nilai_lain = []
nilai_uts = []
nilai_uas = []

baris = 2  # baris 1 adalah judul kolom
while ws.cell(row=baris, column=1).value is not None:
    nama_value = ws.cell(row=baris, column=1).value
    if nama_value is None:
         break

    nama.append(str(nama_value).strip())
    nilai_lain.append(to_float(ws.cell(row=baris, column=3).value))
    nilai_uts.append(to_float(ws.cell(row=baris, column=4).value))
    nilai_uas.append(to_float(ws.cell(row=baris, column=5).value))
    baris += 1    

# 3. List untuk counting 
daftar_grade = ["A", "A-", "B+", "B", "B-", "C+", "C", "TL"]
jumlah_grade = [0, 0, 0, 0, 0, 0, 0, 0]

# 4. Hitung nilai akhir, grade, dan print laporan
print("LAPORAN GRADING MAHASISWA")
print("-" * 40)
print("|{:^4}|{:^15}|{:^8}|{:^8}|".format("No", "Nama", "Nilai", "Grade"))
print("|{:^4}|{:^15}|{:^8}|{:^8}|".format("", "Mahasiswa", "Akhir", ""))
print("|{}|{}|{}|{}|".format("-" * 4, "-" * 15, "-" * 8, "-" * 8))

i = 0
while i < len(nama):
    if i >= len(nilai_lain) or i >= len(nilai_uts) or i >= len(nilai_uas):
        print("Data tidak lengkap di indeks", i)
        break

    NA = 0.30 * nilai_lain[i] + 0.35 * nilai_uts[i] + 0.35 * nilai_uas[i]
    NA = round(NA, 2)
    grade = hitung_grade(NA)

    jumlah_grade[daftar_grade.index(grade)] += 1

    print("|{:^4}| {:<13} |{:^8.2f}|{:^8}|".format(i + 1, nama[i], NA, grade))
    i += 1
print("-" * 40)
print()

# 5. Rekapitulasi 
print("Rekapitulasi :")
print("Grade A  = {}".format(jumlah_grade[0]))
print("Grade A- = {}".format(jumlah_grade[1]))
print("Grade B+ = {}".format(jumlah_grade[2]))
print("Grade B  = {}".format(jumlah_grade[3]))
print("Grade B- = {}".format(jumlah_grade[4]))
print("Grade C+ = {}".format(jumlah_grade[5]))
print("Grade C  = {}".format(jumlah_grade[6]))
print("Tidak Lulus = {}".format(jumlah_grade[7]))
print("Total Mahasiswa = {}".format(len(nama)))
print()
print("selesai")