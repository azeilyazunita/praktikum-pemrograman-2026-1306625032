
# Identitas diri
print("Program Konversi Suhu")
print("Nama : Azeilya Junita")
print("NIM  : 1306625032")
print()

#Input suhu awal, akhir, dan selang
awal = float(input("Masukkan suhu awal  : "))
akhir = float(input("Masukkan suhu akhir : "))
selang = float(input("Masukkan selang     : "))
print()

# Border tabel
print("Tabel Konversi Suhu")
print()
print("="*55)
print('|{:<5}|{:<15}|{:<15}|{:<15}|'.format("No.", "Celcius", "Reamur", "Fahrenheit"))
print("="*55)
n = 1
c = awal

# Hasil data tabel
while c <= akhir:
    celcius = round(c, 3)
    reamur = round(c * 4/5, 3)
    fahrenheit = round(c * 9/5 + 32, 3)
    print('|{:<5}|{:<15}|{:<15}|{:<15}|'.format(n, celcius, reamur, fahrenheit))
    c = c + selang
    n = n + 1

print("="*55)
print()
print("Program Selesai")


